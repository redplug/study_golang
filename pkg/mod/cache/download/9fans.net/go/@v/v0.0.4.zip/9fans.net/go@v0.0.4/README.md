[![Go Reference](https://pkg.go.dev/badge/9fans.net/go.svg)](https://pkg.go.dev/9fans.net/go)

This repository contains packages for interacting with Plan 9
as well as ports of common Plan 9 libraries and tools.
