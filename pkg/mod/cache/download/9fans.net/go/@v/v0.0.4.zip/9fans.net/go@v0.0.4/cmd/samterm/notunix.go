// +build !unix

package main

func extstart() {}
