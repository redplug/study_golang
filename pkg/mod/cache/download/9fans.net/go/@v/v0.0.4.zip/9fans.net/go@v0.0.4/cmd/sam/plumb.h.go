package main

type Plumbmsg struct {
	src   string
	dst   string
	wdir  string
	type_ string
	attr  string
	data  string
	ndata int
}
